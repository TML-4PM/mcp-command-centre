import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE!
)

export default async function handler(req, res) {
  const { data, error } = await supabase
    .schema('ops')
    .from('v_site_control_tower')
    .select('*')
    .order('priority_score', { ascending: false })

  if (error) return res.status(500).json({ error: error.message })
  res.status(200).json(data)
}
