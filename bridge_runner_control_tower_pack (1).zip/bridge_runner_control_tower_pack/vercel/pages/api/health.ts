export default async function handler(req, res) {
  const { url } = req.query

  if (!url) {
    return res.status(400).json({ error: 'Missing url' })
  }

  try {
    const r = await fetch(url, { method: 'HEAD', redirect: 'follow' })
    const status = r.status >= 200 && r.status < 400 ? 'UP' : 'DEGRADED'
    res.status(200).json({ status, code: r.status })
  } catch {
    res.status(200).json({ status: 'DOWN' })
  }
}
