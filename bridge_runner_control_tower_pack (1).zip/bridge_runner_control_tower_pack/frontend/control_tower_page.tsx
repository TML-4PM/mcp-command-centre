import { useEffect, useMemo, useState } from "react";

export default function ControlTowerSitesPage() {
  const [rows, setRows] = useState([]);
  const [search, setSearch] = useState("");
  const [group, setGroup] = useState("All");
  const [focus, setFocus] = useState("All");

  useEffect(() => {
    fetch("/api/sites")
      .then((r) => r.json())
      .then((data) => setRows(Array.isArray(data) ? data : []))
      .catch(() => setRows([]));
  }, []);

  const groups = useMemo(() => ["All", ...Array.from(new Set(rows.map((r) => r.group_name).filter(Boolean)))], [rows]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((row) => {
      const matchesSearch =
        !q ||
        String(row.name || "").toLowerCase().includes(q) ||
        String(row.slug || "").toLowerCase().includes(q) ||
        String(row.canonical_url || "").toLowerCase().includes(q) ||
        String(row.github_repo || "").toLowerCase().includes(q);

      const matchesGroup = group === "All" || row.group_name === group;

      const matchesFocus =
        focus === "All" ||
        (focus === "Missing GitHub" && !row.github_repo) ||
        (focus === "Missing Public" && !row.canonical_url) ||
        (focus === "Health Risk" && row.health_status !== "UP") ||
        (focus === "Reality Risk" && row.reality_status !== "REAL");

      return matchesSearch && matchesGroup && matchesFocus;
    });
  }, [rows, search, group, focus]);

  return (
    <div style={{ fontFamily: "system-ui, sans-serif", padding: 24, background: "#f8fafc", minHeight: "100vh" }}>
      <div style={{ background: "white", borderRadius: 20, padding: 24, border: "1px solid #e2e8f0" }}>
        <h1 style={{ marginTop: 0 }}>Control Tower — Sites</h1>
        <p>Registry truth, health, evidence state, and action readiness in one view.</p>

        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr", gap: 12, marginBottom: 16 }}>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search site, slug, domain, repo" />
          <select value={group} onChange={(e) => setGroup(e.target.value)}>
            {groups.map((g) => <option key={g}>{g}</option>)}
          </select>
          <select value={focus} onChange={(e) => setFocus(e.target.value)}>
            {["All", "Missing GitHub", "Missing Public", "Health Risk", "Reality Risk"].map((f) => <option key={f}>{f}</option>)}
          </select>
        </div>

        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr>
                {["Site","Group","Status","Reality","Health","Public","Vercel","GitHub","Open Actions"].map((h) => (
                  <th key={h} style={{ textAlign: "left", padding: 10, borderBottom: "1px solid #cbd5e1" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((row) => (
                <tr key={row.id}>
                  <td style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>{row.name}</td>
                  <td style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>{row.group_name}</td>
                  <td style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>{row.status}</td>
                  <td style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>{row.reality_status}</td>
                  <td style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>{row.health_status}</td>
                  <td style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>{row.canonical_url || "—"}</td>
                  <td style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>{row.vercel_url || "—"}</td>
                  <td style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>{row.github_repo || "—"}</td>
                  <td style={{ padding: 10, borderBottom: "1px solid #e2e8f0" }}>{row.open_action_count ?? 0}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
