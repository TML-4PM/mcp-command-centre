import json
import os
import boto3
import psycopg2
from psycopg2.extras import RealDictCursor
from shared_events import put_control_tower_event

sqs = boto3.client("sqs")
QUEUE_URL = os.environ["AUTOFIX_QUEUE_URL"]
DB_DSN = os.environ["SUPABASE_DB_DSN"]

TASK_ONLY = {
    "NO_GITHUB",
    "NO_PUBLIC",
    "NO_DEPLOY",
    "DUPLICATE_CANONICAL",
    "MISSING_SUPABASE_BINDING",
}

SAFE_AUTOFIX = {
    "HEALTH_DOWN": "REFRESH_HEALTH",
    "HEALTH_DEGRADED": "REFRESH_HEALTH",
    "REALITY_DRIFT": "RECALC_REALITY",
}

def handler(event, context):
    for record in event.get("Records", []):
        detail = record["detail"]
        site_id = detail["site_id"]
        slug = detail["slug"]
        violation_code = detail["violation_code"]
        requested_fix = detail["requested_fix"]
        dry_run = bool(detail.get("dry_run", True))
        event_id = record.get("id")

        with psycopg2.connect(DB_DSN) as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    insert into ops.site_autofix_log
                    (site_id, slug, violation_code, requested_fix, action_status, dry_run, event_id)
                    values (%s, %s, %s, %s, 'QUEUED', %s, %s)
                """, (site_id, slug, violation_code, requested_fix, dry_run, event_id))

                if violation_code in TASK_ONLY:
                    cur.execute("""
                        insert into ops.site_action_queue
                        (site_id, slug, action_type, severity, title, detail, status, autofixable, source_event_id)
                        values (%s, %s, %s, 'HIGH', %s, %s, 'OPEN', false, %s)
                    """, (
                        site_id,
                        slug,
                        violation_code,
                        f"{violation_code} requires operator action",
                        f"Detected by control tower router for {slug}",
                        event_id
                    ))

                    cur.execute("""
                        update ops.site_autofix_log
                        set action_status = 'SKIPPED',
                            result_message = 'Task created instead of direct autofix',
                            updated_at = now()
                        where site_id = %s and event_id = %s
                    """, (site_id, event_id))

                    put_control_tower_event("site.autofix.completed", {
                        "site_id": site_id,
                        "slug": slug,
                        "violation_code": violation_code,
                        "result": "TASK_CREATED"
                    })
                    continue

                if violation_code in SAFE_AUTOFIX:
                    sqs.send_message(QueueUrl=QUEUE_URL, MessageBody=json.dumps(detail))
    return {"ok": True}
