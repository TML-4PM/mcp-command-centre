import json
import os
import boto3
from datetime import datetime, timezone

events = boto3.client("events")
BUS_NAME = os.environ["EVENT_BUS_NAME"]

def put_control_tower_event(detail_type: str, detail: dict):
    response = events.put_events(
        Entries=[
            {
                "Source": "tech4humanity.controltower",
                "DetailType": detail_type,
                "Detail": json.dumps(detail),
                "EventBusName": BUS_NAME,
                "Time": datetime.now(timezone.utc),
            }
        ]
    )
    if response.get("FailedEntryCount", 0):
        raise RuntimeError(f"PutEvents failed: {response}")
    return response
