import os
import requests
import psycopg2
from psycopg2.extras import RealDictCursor
from shared_events import put_control_tower_event

DB_DSN = os.environ["SUPABASE_DB_DSN"]

def calculate_reality(site):
    if site.get("canonical_url") and site.get("vercel_url") and site.get("github_repo") and site.get("health_status") == "UP":
        return "REAL"
    if site.get("canonical_url") or site.get("vercel_url") or site.get("github_repo"):
        return "PARTIAL"
    return "PRETEND"

def probe(url):
    if not url:
        return "UNKNOWN"
    try:
        r = requests.head(url, timeout=10, allow_redirects=True)
        if 200 <= r.status_code < 400:
            return "UP"
        return "DEGRADED"
    except Exception:
        return "DOWN"

def detect(site, probed_health):
    out = []
    if not site.get("github_repo"):
        out.append(("NO_GITHUB", "CREATE_TASK_ONLY"))
    if not site.get("canonical_url"):
        out.append(("NO_PUBLIC", "CREATE_TASK_ONLY"))
    if not site.get("vercel_url"):
        out.append(("NO_DEPLOY", "CREATE_TASK_ONLY"))
    if probed_health == "DOWN":
        out.append(("HEALTH_DOWN", "REFRESH_HEALTH"))
    elif probed_health == "DEGRADED":
        out.append(("HEALTH_DEGRADED", "REFRESH_HEALTH"))
    calculated = calculate_reality({**site, "health_status": probed_health})
    if site.get("reality_status") != calculated:
        out.append(("REALITY_DRIFT", "RECALC_REALITY"))
    return out

def handler(event, context):
    dry_run = bool(event.get("dry_run", True))
    with psycopg2.connect(DB_DSN) as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                select id, slug, name, canonical_url, vercel_url, github_repo,
                       reality_status, health_status
                from ops.site_registry
            """)
            sites = cur.fetchall()

            for site in sites:
                probed_health = probe(site["canonical_url"])

                cur.execute("""
                    update ops.site_registry
                    set health_status = %s,
                        last_checked = now()
                    where id = %s
                """, (probed_health, site["id"]))

                for violation_code, requested_fix in detect(site, probed_health):
                    put_control_tower_event(
                        "site.violation.detected",
                        {
                            "site_id": str(site["id"]),
                            "slug": site["slug"],
                            "violation_code": violation_code,
                            "requested_fix": requested_fix,
                            "requested_by": "t4h-site-scan-launcher",
                            "dry_run": dry_run
                        }
                    )
    return {"ok": True}
