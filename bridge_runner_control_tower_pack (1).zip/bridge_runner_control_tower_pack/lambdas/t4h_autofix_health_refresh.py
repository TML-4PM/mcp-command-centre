import json
import os
import requests
import psycopg2
from psycopg2.extras import RealDictCursor
from shared_events import put_control_tower_event

DB_DSN = os.environ["SUPABASE_DB_DSN"]

def probe(url):
    if not url:
        return "UNKNOWN"
    try:
        r = requests.head(url, timeout=10, allow_redirects=True)
        if 200 <= r.status_code < 400:
            return "UP"
        return "DEGRADED"
    except Exception:
        return "DOWN"

def handler(event, context):
    for r in event.get("Records", []):
        detail = json.loads(r["body"]) if isinstance(r.get("body"), str) else r
        site_id = detail["site_id"]
        slug = detail["slug"]

        with psycopg2.connect(DB_DSN) as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("select * from ops.site_registry where id = %s", (site_id,))
                site = cur.fetchone()
                if not site:
                    continue

                before_state = dict(site)
                new_health = probe(site["canonical_url"])

                cur.execute("""
                    update ops.site_registry
                    set health_status = %s,
                        last_checked = now(),
                        updated_at = now()
                    where id = %s
                    returning *
                """, (new_health, site_id))
                after_state = cur.fetchone()

                cur.execute("""
                    update ops.site_autofix_log
                    set action_status = 'SUCCESS',
                        before_state = %s::jsonb,
                        after_state = %s::jsonb,
                        result_message = %s,
                        updated_at = now()
                    where site_id = %s
                      and violation_code in ('HEALTH_DOWN','HEALTH_DEGRADED')
                      and action_status in ('QUEUED','RUNNING')
                """, (
                    json.dumps(before_state),
                    json.dumps(dict(after_state)),
                    f"Health refreshed to {new_health}",
                    site_id
                ))

                put_control_tower_event("site.autofix.completed", {
                    "site_id": site_id,
                    "slug": slug,
                    "violation_code": detail["violation_code"],
                    "result": f"HEALTH_{new_health}"
                })
    return {"ok": True}
