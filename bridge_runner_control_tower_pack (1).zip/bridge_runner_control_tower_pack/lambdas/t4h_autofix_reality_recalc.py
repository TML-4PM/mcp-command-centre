import json
import os
import psycopg2
from psycopg2.extras import RealDictCursor
from shared_events import put_control_tower_event

DB_DSN = os.environ["SUPABASE_DB_DSN"]

def calc(site):
    if site.get("canonical_url") and site.get("vercel_url") and site.get("github_repo") and site.get("health_status") == "UP":
        return "REAL"
    if site.get("canonical_url") or site.get("vercel_url") or site.get("github_repo"):
        return "PARTIAL"
    return "PRETEND"

def handler(event, context):
    for r in event.get("Records", []):
        detail = json.loads(r["body"]) if isinstance(r.get("body"), str) else r
        site_id = detail["site_id"]
        slug = detail["slug"]

        with psycopg2.connect(DB_DSN) as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("select * from ops.site_registry where id = %s", (site_id,))
                site = cur.fetchone()
                if not site:
                    continue

                before_state = dict(site)
                new_reality = calc(site)

                cur.execute("""
                    update ops.site_registry
                    set reality_status = %s,
                        updated_at = now()
                    where id = %s
                    returning *
                """, (new_reality, site_id))
                after_state = cur.fetchone()

                cur.execute("""
                    update ops.site_autofix_log
                    set action_status = 'SUCCESS',
                        before_state = %s::jsonb,
                        after_state = %s::jsonb,
                        result_message = %s,
                        updated_at = now()
                    where site_id = %s
                      and violation_code = 'REALITY_DRIFT'
                      and action_status in ('QUEUED','RUNNING')
                """, (
                    json.dumps(before_state),
                    json.dumps(dict(after_state)),
                    f"Reality recalculated to {new_reality}",
                    site_id
                ))

                put_control_tower_event("site.autofix.completed", {
                    "site_id": site_id,
                    "slug": slug,
                    "violation_code": "REALITY_DRIFT",
                    "result": new_reality
                })
    return {"ok": True}
