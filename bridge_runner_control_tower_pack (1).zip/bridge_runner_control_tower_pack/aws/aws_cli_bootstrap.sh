#!/usr/bin/env bash
set -euo pipefail

AWS_REGION="${AWS_REGION:-ap-southeast-2}"
AWS_ACCOUNT_ID="${AWS_ACCOUNT_ID:-123456789012}"

BUS_NAME="t4h.controltower"
SCHEDULE_GROUP="t4h-controltower"
QUEUE_NAME="t4h-controltower-autofix"

SCAN_LAMBDA_ARN="arn:aws:lambda:${AWS_REGION}:${AWS_ACCOUNT_ID}:function:t4h-site-scan-launcher"
ROUTER_LAMBDA_ARN="arn:aws:lambda:${AWS_REGION}:${AWS_ACCOUNT_ID}:function:t4h-autofix-router"
SCHEDULER_ROLE_ARN="arn:aws:iam::${AWS_ACCOUNT_ID}:role/eventbridge-scheduler-invoke-lambda-role"

aws events create-event-bus --name "${BUS_NAME}" || true
aws scheduler create-schedule-group --name "${SCHEDULE_GROUP}" || true
aws sqs create-queue --queue-name "${QUEUE_NAME}" || true

aws events put-rule   --name t4h-site-violation-router   --event-bus-name "${BUS_NAME}"   --event-pattern '{
    "source": ["tech4humanity.controltower"],
    "detail-type": ["site.violation.detected"]
  }'

aws events put-targets   --event-bus-name "${BUS_NAME}"   --rule t4h-site-violation-router   --targets "[{\"Id\":\"1\",\"Arn\":\"${ROUTER_LAMBDA_ARN}\"}]"

aws scheduler create-schedule   --name t4h-site-scan-hourly   --group-name "${SCHEDULE_GROUP}"   --schedule-expression "rate(1 hour)"   --flexible-time-window '{"Mode":"OFF"}'   --target "{\"Arn\":\"${SCAN_LAMBDA_ARN}\",\"RoleArn\":\"${SCHEDULER_ROLE_ARN}\",\"Input\":\"{\\\"scan_mode\\\":\\\"light\\\",\\\"dry_run\\\":true}\"}" || true

aws scheduler create-schedule   --name t4h-site-scan-nightly   --group-name "${SCHEDULE_GROUP}"   --schedule-expression "cron(0 2 * * ? *)"   --schedule-expression-timezone "Australia/Sydney"   --flexible-time-window '{"Mode":"OFF"}'   --target "{\"Arn\":\"${SCAN_LAMBDA_ARN}\",\"RoleArn\":\"${SCHEDULER_ROLE_ARN}\",\"Input\":\"{\\\"scan_mode\\\":\\\"full\\\",\\\"dry_run\\\":false}\"}" || true
